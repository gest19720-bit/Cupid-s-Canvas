import React, { useState, useEffect, useRef } from 'react';
import { Sparkles, X, Send, User, Bot, RefreshCcw, Zap, Brain, Globe, ExternalLink, Key } from 'lucide-react';
import { createChat } from '../geminiService';
import { Message, AiMode } from '../types';
import { Chat, GenerateContentResponse } from '@google/genai';

interface ChatBotProps {
  onClose: () => void;
}

const SYSTEM_INSTRUCTION = `You are 'Cupid AI', a world-class romantic companion. 
Your mission is to help users write perfect, heartfelt Valentine's wishes.

STRICT CLEAN OUTPUT RULES:
- NEVER use Markdown headers (e.g., #, ##, ###).
- NEVER use bold or italics formatting (e.g., **, *, __, _).
- NEVER use bullet points, dashes, or numbered lists.
- Output ONLY plain, elegant text that looks like a handwritten letter.
- Use natural spacing (empty lines) between sections if needed.
- Keep the tone poetic, sophisticated, and deeply sincere.
- Avoid all technical or special characters.`;

const ChatBot: React.FC<ChatBotProps> = ({ onClose }) => {
  const [messages, setMessages] = useState<Message[]>([
    { id: '1', role: 'model', text: 'Greetings, dear one. I am Cupid AI, your guide to the heart. Together, we shall weave words of love that will be cherished forever.' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [aiMode, setAiMode] = useState<AiMode>('fast');
  const [needsKey, setNeedsKey] = useState(false);
  const chatRef = useRef<Chat | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Initialize or re-initialize chat when mode changes
  useEffect(() => {
    const initChat = async () => {
      // High-tier models like Gemini 3 Pro require a paid API key selection
      if (aiMode === 'thinking' || aiMode === 'search') {
        const hasKey = await (window as any).aistudio?.hasSelectedApiKey();
        if (!hasKey) {
          setNeedsKey(true);
          return;
        }
      }
      setNeedsKey(false);
      chatRef.current = createChat(SYSTEM_INSTRUCTION, aiMode);
    };
    initChat();
  }, [aiMode]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleOpenKeySelector = async () => {
    await (window as any).aistudio?.openSelectKey();
    // Proceed to initialize chat assuming key selection was successful
    setNeedsKey(false);
    chatRef.current = createChat(SYSTEM_INSTRUCTION, aiMode);
  };

  const handleSend = async () => {
    if (!input.trim() || !chatRef.current || isLoading) return;

    const userMessage: Message = { id: Date.now().toString(), role: 'user', text: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const response: GenerateContentResponse = await chatRef.current.sendMessage({ message: input });
      
      const links: { title: string; uri: string }[] = [];
      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      if (chunks) {
        chunks.forEach((chunk: any) => {
          if (chunk.web) {
            links.push({ title: chunk.web.title, uri: chunk.web.uri });
          }
        });
      }

      const botMessage: Message = { 
        id: (Date.now() + 1).toString(), 
        role: 'model', 
        text: response.text || "My apologies, I was lost in a dream of love. Please share your thoughts again.",
        links: links.length > 0 ? links : undefined
      };
      setMessages(prev => [...prev, botMessage]);
    } catch (err: any) {
      console.error(err);
      // Recovery logic for 404 NOT_FOUND error as per guidelines
      if (err.message?.includes('Requested entity was not found')) {
        setNeedsKey(true);
        setMessages(prev => [...prev, { id: 'err-404', role: 'model', text: 'It seems I need a special key to think this deeply. Please select an API key from a paid project to continue.' }]);
      } else {
        setMessages(prev => [...prev, { id: 'err', role: 'model', text: 'My arrows have gone astray. Let us try once more to find the right words.' }]);
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-rose-50/20">
      <div className="bg-rose-500 p-6 text-white flex flex-col gap-4 shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-white/20 p-2 rounded-xl">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-lg">Cupid AI</h3>
              <p className="text-[10px] text-rose-100 uppercase tracking-widest font-bold">Poetic Assistant</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-rose-600 rounded-xl transition-all active:scale-95">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="flex bg-rose-600/50 p-1 rounded-2xl border border-rose-400/30">
          {[
            { id: 'fast', label: 'Whisper', icon: Zap, desc: 'Ultra-fast response' },
            { id: 'thinking', label: 'Wisdom', icon: Brain, desc: 'Deep thinking for complexity' },
            { id: 'search', label: 'Wander', icon: Globe, desc: 'Real-time web search' }
          ].map(mode => (
            <button
              key={mode.id}
              onClick={() => setAiMode(mode.id as AiMode)}
              className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all ${aiMode === mode.id ? 'bg-white text-rose-600 shadow-sm' : 'text-rose-100 hover:bg-white/10'}`}
              title={mode.desc}
            >
              <mode.icon className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{mode.label}</span>
            </button>
          ))}
        </div>
      </div>

      {needsKey ? (
        <div className="flex-1 flex flex-col items-center justify-center p-8 text-center space-y-6">
          <div className="w-20 h-20 bg-rose-100 rounded-full flex items-center justify-center text-rose-500">
            <Key className="w-10 h-10" />
          </div>
          <div className="space-y-2">
            <h4 className="text-xl font-bold text-slate-800">Paid API Key Required</h4>
            <p className="text-slate-500 text-sm leading-relaxed">
              {aiMode === 'thinking' ? 'Deep Thinking' : 'Web Search'} uses the advanced Gemini 3 Pro model. 
              Please select an API key from a project with billing enabled.
            </p>
            <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noopener noreferrer" className="text-xs text-rose-500 font-bold hover:underline">Learn about Gemini API billing</a>
          </div>
          <button 
            onClick={handleOpenKeySelector}
            className="w-full py-4 bg-rose-600 text-white rounded-2xl font-bold uppercase tracking-widest text-xs hover:bg-rose-700 transition-all shadow-xl shadow-rose-100"
          >
            Select Paid API Key
          </button>
        </div>
      ) : (
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
          {messages.map((msg) => (
            <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`flex gap-2 max-w-[85%] ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${msg.role === 'user' ? 'bg-rose-500 text-white' : 'bg-white border border-rose-100 text-rose-500 shadow-sm'}`}>
                  {msg.role === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                </div>
                <div className="space-y-2">
                  <div className={`px-4 py-3 rounded-2xl shadow-sm ${msg.role === 'user' ? 'bg-rose-500 text-white rounded-tr-none' : 'bg-white text-slate-700 rounded-tl-none border border-rose-50'}`}>
                    <p className="text-sm leading-relaxed whitespace-pre-wrap font-serif">{msg.text}</p>
                  </div>
                  {msg.links && msg.links.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-2">
                      {msg.links.map((link, i) => (
                        <a 
                          key={i} 
                          href={link.uri} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="flex items-center gap-1.5 px-3 py-1.5 bg-white/80 border border-slate-200 rounded-full text-[10px] text-slate-500 hover:text-rose-500 hover:border-rose-200 transition-all shadow-sm"
                        >
                          <ExternalLink className="w-3 h-3" />
                          <span className="max-w-[120px] truncate">{link.title}</span>
                        </a>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start">
              <div className="flex gap-2 items-center bg-white px-4 py-2 rounded-full border border-rose-50 shadow-sm animate-pulse">
                <RefreshCcw className="w-3.5 h-3.5 text-rose-500 animate-spin" />
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                  {aiMode === 'thinking' ? 'Deep Thinking...' : aiMode === 'search' ? 'Searching the Web...' : 'Gemini is Typing...'}
                </span>
              </div>
            </div>
          )}
        </div>
      )}

      <div className="p-4 bg-white border-t border-rose-50">
        <div className="flex gap-2 items-end">
          <textarea
            value={input}
            disabled={needsKey}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder={aiMode === 'search' ? "Ask me anything about current events..." : "Write your heart's desire..."}
            className="flex-1 bg-rose-50/50 rounded-2xl px-4 py-3 text-sm focus:ring-2 focus:ring-rose-500 outline-none resize-none max-h-32 shadow-inner disabled:opacity-50"
            rows={2}
          />
          <button 
            onClick={handleSend}
            disabled={!input.trim() || isLoading || needsKey}
            className="bg-rose-500 text-white p-3.5 rounded-2xl disabled:bg-slate-200 transition-all hover:scale-105 active:scale-95 shadow-lg shadow-rose-200"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
        <p className="text-[9px] text-slate-300 text-center mt-3 uppercase font-bold tracking-tighter">
          Powered by {aiMode === 'thinking' ? 'Gemini 3 Pro (Wisdom)' : aiMode === 'search' ? 'Gemini 3 Flash (Wander)' : 'Gemini 2.5 Flash Lite (Whisper)'}
        </p>
      </div>
    </div>
  );
};

export default ChatBot;