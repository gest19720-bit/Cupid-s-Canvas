import React, { useRef, useState } from 'react';
import { ImageIcon, Plus, Trash2, Sparkles, Video, Info } from 'lucide-react';

interface VideoMemorySectionProps {
  images: string[];
  onImagesChange: (images: string[]) => void;
  onGenerate: () => void;
  isLoading: boolean;
}

const VideoMemorySection: React.FC<VideoMemorySectionProps> = ({ images, onImagesChange, onGenerate, isLoading }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileList = e.target.files;
    if (!fileList) return;

    const files = Array.from(fileList) as File[];
    
    if (images.length + files.length > 20) {
      setError("Maximum 20 memories allowed.");
      return;
    }
    setError(null);

    const newImageBatch: string[] = [];
    let completedCount = 0;

    files.forEach((file: File) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          newImageBatch.push(reader.result);
        }
        completedCount++;
        
        // Only trigger update once all files in the batch are read to avoid flickering/race conditions
        if (completedCount === files.length) {
          onImagesChange([...images, ...newImageBatch]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const removeImage = (index: number) => {
    onImagesChange(images.filter((_, i) => i !== index));
  };

  return (
    <section className="max-w-4xl mx-auto mt-20 p-8 glass rounded-[3rem] border border-rose-100 shadow-xl animate-in fade-in duration-1000">
      <div className="text-center mb-10 space-y-3">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-rose-500 text-white text-[10px] font-bold tracking-widest uppercase">
          <Video className="w-3 h-3" /> Digital Memory Lane
        </div>
        <h3 className="text-3xl font-romantic text-rose-600">Create an AI Memory Movie</h3>
        <p className="text-slate-500 text-sm max-w-lg mx-auto leading-relaxed">
          Upload up to 20 photos of your journey together. Gemini will analyze your memories and weave them into a cinematic love story.
        </p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 gap-4">
        {images.map((img, idx) => (
          <div key={idx} className="group relative aspect-square rounded-2xl overflow-hidden shadow-sm border border-rose-50 hover:scale-105 transition-all duration-300">
            <img src={img} alt={`Memory ${idx}`} className="w-full h-full object-cover" />
            <button 
              onClick={() => removeImage(idx)}
              className="absolute top-2 right-2 p-1.5 bg-white/80 backdrop-blur-md text-rose-500 rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow-sm hover:bg-rose-500 hover:text-white"
            >
              <Trash2 className="w-3 h-3" />
            </button>
          </div>
        ))}

        {images.length < 20 && (
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="aspect-square rounded-2xl border-2 border-dashed border-rose-200 bg-rose-50/30 flex flex-col items-center justify-center gap-2 text-rose-400 hover:bg-rose-50 hover:border-rose-300 transition-all group"
          >
            <div className="p-3 bg-white rounded-xl shadow-sm group-hover:scale-110 transition-transform">
              <Plus className="w-6 h-6" />
            </div>
            <span className="text-[10px] font-bold uppercase tracking-tighter">Add Photo</span>
          </button>
        )}
        <input 
          type="file" 
          ref={fileInputRef} 
          multiple 
          accept="image/*" 
          className="hidden" 
          onChange={handleFileChange} 
        />
      </div>

      {error && (
        <p className="text-rose-500 text-xs text-center mt-4 font-bold flex items-center justify-center gap-1">
          <Info className="w-3 h-3" /> {error}
        </p>
      )}

      <div className="mt-12 flex justify-center">
        <button 
          onClick={onGenerate}
          disabled={images.length === 0 || isLoading}
          className="group relative px-12 py-5 bg-rose-500 text-white rounded-full font-bold shadow-2xl shadow-rose-200 hover:bg-rose-600 transition-all active:scale-95 disabled:bg-slate-200 disabled:shadow-none"
        >
          {isLoading ? (
            <div className="flex items-center gap-3">
              <Sparkles className="w-5 h-5 animate-spin" />
              <span>Weaving Your Story...</span>
            </div>
          ) : (
            <div className="flex items-center gap-3">
              <Sparkles className="w-5 h-5 group-hover:rotate-12 transition-transform" />
              <span>Generate AI Memory Movie</span>
            </div>
          )}
        </button>
      </div>
    </section>
  );
};

export default VideoMemorySection;