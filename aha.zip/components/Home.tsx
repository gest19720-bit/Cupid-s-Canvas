import React from 'react';
import { Sparkles, ArrowRight, Star, Heart } from 'lucide-react';

interface HomeProps {
  onStart: () => void;
}

const Home: React.FC<HomeProps> = ({ onStart }) => {
  return (
    <div className="space-y-32 py-20 overflow-hidden">
      {/* Editorial Hero */}
      <section className="relative flex flex-col items-center text-center space-y-12">
        <div className="flex items-center gap-2 px-6 py-2 bg-rose-50 text-rose-600 rounded-full text-[10px] font-bold uppercase tracking-[0.3em] animate-in fade-in slide-in-from-top duration-1000">
          <Sparkles className="w-3 h-3" />
          Gemini Intelligence for the Heart
        </div>

        <h1 className="text-7xl md:text-[9rem] font-bold tracking-tighter text-slate-900 leading-[0.85] animate-in zoom-in duration-1000 delay-100">
          Digital <br />
          <span className="text-rose-600 italic font-romantic font-normal">Romance.</span>
        </h1>

        <p className="text-xl md:text-2xl text-slate-500 max-w-2xl mx-auto font-medium leading-relaxed animate-in fade-in duration-1000 delay-300">
          Elevate your Valentine's wish with world-class AI. <br />
          Crafted for those who speak the language of deep devotion.
        </p>

        <div className="flex gap-6 animate-in fade-in slide-in-from-bottom duration-1000 delay-500">
          <button 
            onClick={onStart}
            className="btn-premium px-10 py-5 bg-slate-900 text-white rounded-full font-bold uppercase tracking-widest text-xs flex items-center gap-3"
          >
            Start Creation <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Abstract Background Elements */}
        <div className="absolute -top-40 -left-40 w-96 h-96 bg-rose-100/30 rounded-full blur-[100px] -z-10" />
        <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-indigo-100/30 rounded-full blur-[100px] -z-10" />
      </section>

      {/* High-End Features */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {[
          {
            title: "Artistic Enhancement.",
            desc: "Advanced neural filters that turn everyday snapshots into romantic masterpieces using Gemini 2.5 Flash Image.",
            tag: "Visuals"
          },
          {
            title: "Poetic Precision.",
            desc: "Let Cupid AI weave your sentiments into professional-grade prose and heartfelt verse.",
            tag: "Narrative"
          },
          {
            title: "Digital Heirlooms.",
            desc: "Export 4K card designs or cinematic reveal stories that last a lifetime.",
            tag: "Format"
          }
        ].map((item, i) => (
          <div key={i} className="group p-10 bg-white border border-slate-100 rounded-[3rem] transition-all hover:border-rose-100 hover:shadow-2xl hover:shadow-rose-50">
             <div className="mb-6 flex justify-between items-center">
                <span className="text-[10px] font-bold uppercase tracking-widest text-rose-500">{item.tag}</span>
                <Star className="w-4 h-4 text-slate-200 group-hover:text-rose-300 transition-colors" />
             </div>
             <h3 className="text-2xl font-bold tracking-tight mb-4">{item.title}</h3>
             <p className="text-slate-500 leading-relaxed font-medium">{item.desc}</p>
          </div>
        ))}
      </section>

      {/* Luxury Quote */}
      <section className="text-center py-20 border-y border-slate-100">
         <Heart className="w-10 h-10 text-rose-600 fill-current mx-auto mb-8 opacity-20" />
         <blockquote className="text-4xl md:text-5xl font-romantic text-slate-800 leading-tight italic">
            "In the garden of time, <br /> our love is the only bloom that never fades."
         </blockquote>
      </section>
    </div>
  );
};

export default Home;
