
import React from 'react';
import { Heart, Trash2, Eye, Download, Calendar } from 'lucide-react';
import { SavedCard } from '../types';

interface GalleryProps {
  cards: SavedCard[];
  onView: (card: SavedCard) => void;
  onDelete: (id: string) => void;
}

const Gallery: React.FC<GalleryProps> = ({ cards, onView, onDelete }) => {
  if (cards.length === 0) {
    return (
      <div className="text-center py-20 space-y-6 animate-in fade-in duration-500">
        <div className="w-24 h-24 bg-rose-50 rounded-full flex items-center justify-center mx-auto">
          <Heart className="w-12 h-12 text-rose-200" />
        </div>
        <h3 className="text-2xl font-romantic text-slate-400">Your gallery is empty...</h3>
        <p className="text-slate-500 max-w-xs mx-auto">Start creating beautiful wishes to see them appear here!</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 py-10">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold text-slate-800">My Saved Wishes</h2>
        <span className="bg-rose-100 text-rose-600 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
          {cards.length} {cards.length === 1 ? 'Card' : 'Cards'}
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {cards.map((card) => (
          <div 
            key={card.id} 
            className="group relative bg-white rounded-[2rem] overflow-hidden shadow-sm hover:shadow-xl transition-all border border-rose-50 animate-in zoom-in-95 duration-300"
          >
            {/* Thumbnail */}
            <div className="aspect-[4/3] bg-rose-50 overflow-hidden relative">
              {card.imageUrl ? (
                <img src={card.imageUrl} alt="Card Preview" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-rose-200">
                  <Heart className="w-12 h-12 fill-current" />
                </div>
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
                <p className="text-white font-romantic text-lg">For {card.recipient}</p>
              </div>
            </div>

            {/* Info */}
            <div className="p-6 space-y-4">
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <Calendar className="w-3 h-3" />
                {new Date(card.createdAt).toLocaleDateString()}
              </div>
              <div>
                <h4 className="font-bold text-slate-800 truncate">Wish for {card.recipient}</h4>
                <p className="text-slate-500 text-sm line-clamp-1 italic">"{card.message}"</p>
              </div>
              
              <div className="flex gap-2 pt-2 border-t border-rose-50">
                <button 
                  onClick={() => onView(card)}
                  className="flex-1 bg-rose-50 text-rose-600 p-2 rounded-xl hover:bg-rose-100 transition-colors flex items-center justify-center gap-2 text-sm font-semibold"
                >
                  <Eye className="w-4 h-4" /> View
                </button>
                <button 
                  onClick={() => onDelete(card.id)}
                  className="bg-slate-50 text-slate-400 p-2 rounded-xl hover:bg-rose-50 hover:text-rose-500 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Gallery;
