
import React from 'react';
import { Phone, MessageSquare, MessageCircle, Heart } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white/50 backdrop-blur-md border-t border-rose-100 py-12 px-6 mt-20">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 items-start">
          {/* Branding */}
          <div className="space-y-4 text-center md:text-left">
            <div className="flex items-center justify-center md:justify-start gap-2">
              <Heart className="text-rose-500 fill-rose-500 w-6 h-6" />
              <span className="text-xl font-romantic text-rose-600">Cupid's Canvas</span>
            </div>
            <p className="text-slate-500 text-sm leading-relaxed max-w-xs mx-auto md:mx-0">
              Spreading love and creativity through AI-powered artistry. Crafting memories, one card at a time.
            </p>
          </div>

          {/* Contact Section */}
          <div className="md:col-span-2">
            <h4 className="text-slate-800 font-bold mb-6 text-center md:text-left">Get in Touch</h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              <a 
                href="tel:+233559583295" 
                className="group flex flex-col items-center md:items-start gap-3 p-4 rounded-2xl bg-white border border-rose-50 hover:border-rose-200 transition-all shadow-sm hover:shadow-md"
              >
                <div className="w-10 h-10 rounded-full bg-rose-50 flex items-center justify-center text-rose-500 group-hover:bg-rose-500 group-hover:text-white transition-colors">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Phone</p>
                  <p className="text-slate-700 font-medium">+233 55 958 3295</p>
                </div>
              </a>

              <a 
                href="sms:+233559583295" 
                className="group flex flex-col items-center md:items-start gap-3 p-4 rounded-2xl bg-white border border-rose-50 hover:border-rose-200 transition-all shadow-sm hover:shadow-md"
              >
                <div className="w-10 h-10 rounded-full bg-rose-50 flex items-center justify-center text-rose-500 group-hover:bg-rose-500 group-hover:text-white transition-colors">
                  <MessageSquare className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">SMS</p>
                  <p className="text-slate-700 font-medium">+233 55 958 3295</p>
                </div>
              </a>

              <a 
                href="https://wa.me/233559583295" 
                target="_blank" 
                rel="noopener noreferrer"
                className="group flex flex-col items-center md:items-start gap-3 p-4 rounded-2xl bg-white border border-rose-50 hover:border-rose-200 transition-all shadow-sm hover:shadow-md"
              >
                <div className="w-10 h-10 rounded-full bg-rose-50 flex items-center justify-center text-rose-500 group-hover:bg-rose-500 group-hover:text-white transition-colors">
                  <MessageCircle className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">WhatsApp</p>
                  <p className="text-slate-700 font-medium">Chat with us</p>
                </div>
              </a>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-rose-50 flex flex-col md:flex-row items-center justify-between gap-4 text-slate-400 text-xs">
          <p>© {new Date().getFullYear()} Cupid's Canvas. All rights reserved.</p>
          <div className="flex items-center gap-1">
            <span>Made with</span>
            <Heart className="w-3 h-3 text-rose-500 fill-current" />
            <span>for lovers everywhere.</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
