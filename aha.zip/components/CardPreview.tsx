import React, { useRef, useState } from 'react';
import { CardState } from '../types';
import { 
  Heart, 
  Sparkles, 
  Download, 
  Share2,
  Check,
  X,
  Copy,
  Stars, 
  Flower2, 
  Feather, 
  Sparkle,
  Trees,
  Sun,
  Crown,
  Waves,
  Film,
  Flower
} from 'lucide-react';
import html2canvas from 'html2canvas';

interface CardPreviewProps {
  card: CardState;
  fullSize?: boolean;
  onGenerateVideo?: () => void;
  videoUrl?: string | null;
}

const CardPreview: React.FC<CardPreviewProps> = ({ card, fullSize = false, onGenerateVideo, videoUrl }) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [isCopying, setIsCopying] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [shareUrl, setShareUrl] = useState('');

  const handleDownload = async () => {
    if (!cardRef.current) return;
    try {
      const canvas = await html2canvas(cardRef.current, {
        useCORS: true,
        scale: 4,
        backgroundColor: '#ffffff',
        logging: false,
      });
      const link = document.createElement('a');
      link.download = `CupidCanvas_${card.recipient}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
    } catch (err) {
      console.error("Export failed, falling back to print", err);
      window.print();
    }
  };

  const handleShare = () => {
    try {
      const shareableData = {
        recipient: card.recipient,
        sender: card.sender,
        message: card.message,
        theme: card.theme,
        fontFamily: card.fontFamily,
        imageUrl: card.imageUrl && card.imageUrl.length < 5000 ? card.imageUrl : null
      };

      // Robust UTF-8 encoding for Base64
      const jsonString = JSON.stringify(shareableData);
      const bytes = new TextEncoder().encode(jsonString);
      const binString = Array.from(bytes, (byte) => String.fromCodePoint(byte)).join("");
      const encoded = btoa(binString);
      
      const url = `${window.location.origin}${window.location.pathname}?wish=${encoded}`;
      setShareUrl(url);
      setShowShareModal(true);
    } catch (err) {
      console.error(err);
      alert("Could not generate share link. Please try again.");
    }
  };

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setIsCopying(true);
      setTimeout(() => setIsCopying(false), 2000);
    } catch (err) {
      alert("Copy failed. Please manually select the link.");
    }
  };

  const getThemeStyles = () => {
    switch (card.theme) {
      case 'midnight':
        return {
          bg: 'bg-slate-950',
          text: 'text-white',
          accent: 'text-rose-400',
          border: 'border-slate-800',
          icon: <Stars className="absolute top-10 right-10 w-20 h-20 text-white/5 opacity-50" />
        };
      case 'vintage':
        return {
          bg: 'bg-[#fdf6e3]',
          text: 'text-amber-950',
          accent: 'text-amber-700',
          border: 'border-amber-100',
          icon: <Feather className="absolute top-10 left-10 w-24 h-24 text-amber-900/5 rotate-12" />
        };
      case 'classic':
        return {
          bg: 'bg-rose-600',
          text: 'text-white',
          accent: 'text-white',
          border: 'border-rose-700',
          icon: <Heart className="absolute bottom-10 left-10 w-32 h-32 text-white/10" />
        };
      case 'minimalist':
        return {
          bg: 'bg-white',
          text: 'text-slate-900',
          accent: 'text-rose-500',
          border: 'border-slate-100',
          icon: <Flower2 className="absolute top-12 left-12 w-20 h-20 text-rose-500/5" />
        };
      case 'celestial':
        return {
          bg: 'bg-indigo-950',
          text: 'text-indigo-100',
          accent: 'text-yellow-400',
          border: 'border-indigo-900',
          icon: <Stars className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 text-white/5" />
        };
      case 'forest':
        return {
          bg: 'bg-emerald-950',
          text: 'text-emerald-50',
          accent: 'text-emerald-400',
          border: 'border-emerald-900',
          icon: <Trees className="absolute top-10 right-10 w-24 h-24 text-emerald-500/5" />
        };
      case 'sunset':
        return {
          bg: 'bg-orange-600',
          text: 'text-white',
          accent: 'text-yellow-300',
          border: 'border-orange-700',
          icon: <Sun className="absolute top-10 left-10 w-24 h-24 text-white/10" />
        };
      case 'royal':
        return {
          bg: 'bg-purple-950',
          text: 'text-amber-100',
          accent: 'text-amber-400',
          border: 'border-purple-900',
          icon: <Crown className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 text-amber-500/5" />
        };
      case 'ocean':
        return {
          bg: 'bg-cyan-950',
          text: 'text-cyan-50',
          accent: 'text-cyan-300',
          border: 'border-cyan-900',
          icon: <Waves className="absolute bottom-0 left-0 w-full h-32 text-cyan-400/5" />
        };
      case 'noir':
        return {
          bg: 'bg-black',
          text: 'text-white',
          accent: 'text-slate-400',
          border: 'border-slate-900',
          icon: <Film className="absolute top-10 right-10 w-20 h-20 text-white/5" />
        };
      case 'sakura':
        return {
          bg: 'bg-[#fff1f2]',
          text: 'text-rose-900',
          accent: 'text-rose-500',
          border: 'border-rose-100',
          icon: <Flower className="absolute top-10 left-10 w-24 h-24 text-rose-500/10" />
        };
      default:
        return {
          bg: 'bg-rose-50',
          text: 'text-rose-950',
          accent: 'text-rose-600',
          border: 'border-rose-100',
          icon: <Sparkle className="absolute top-10 right-10 w-20 h-20 text-rose-500/10" />
        };
    }
  };

  const getFontClass = (id: string) => {
    switch (id) {
      case 'romantic': return 'font-romantic text-3xl sm:text-4xl';
      case 'elegant': return 'font-elegant text-2xl sm:text-3xl tracking-tight';
      case 'serif-soft': return 'font-serif-soft text-xl sm:text-2xl italic';
      case 'script-alt': return 'font-script-alt text-3xl sm:text-4xl';
      default: return 'font-sans text-lg sm:text-xl font-medium';
    }
  };

  const theme = getThemeStyles();
  const fontClass = getFontClass(card.fontFamily);

  return (
    <>
      <div className={`card-preview-container ${fullSize ? 'max-w-xl mx-auto' : 'w-full'} perspective-1000`}>
        <div 
          ref={cardRef}
          className={`relative aspect-[4/5] rounded-[3.5rem] shadow-2xl overflow-hidden border-[16px] ring-1 ring-black/5 transition-all duration-700 group ${theme.bg} ${theme.border}`}
        >
          <div className="absolute inset-0 opacity-[0.03] pointer-events-none mix-blend-overlay bg-[url('https://www.transparenttextures.com/patterns/paper-fibers.png')]" />

          {theme.icon}

          {/* Watermark */}
          <div className={`absolute top-10 right-10 z-20 pointer-events-none opacity-40 flex items-center gap-1 text-[10px] font-bold uppercase tracking-[0.2em] ${theme.text}`}>
            <span className="text-rose-600">❤️</span>Cupid's Canvas
          </div>

          <div className="relative h-full flex flex-col p-10 sm:p-16">
             <header className="text-center mb-10">
                <span className={`text-[10px] font-bold uppercase tracking-[0.4em] mb-4 block opacity-50 ${theme.text}`}>Eternally Yours</span>
                <h2 className={`text-5xl font-romantic leading-none ${theme.accent}`}>{card.recipient}</h2>
             </header>

             <div className={`flex-1 relative rounded-[2.5rem] overflow-hidden shadow-2xl ring-4 ring-white/10 mb-10`}>
                {card.imageUrl ? (
                  <img src={card.imageUrl} className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" alt="Main" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-black/5">
                    <Heart className={`w-16 h-16 fill-current opacity-20 ${theme.accent}`} />
                  </div>
                )}
             </div>

             <footer className="text-center space-y-6">
                <p className={`leading-tight tracking-tight px-4 opacity-90 transition-all duration-500 ${theme.text} ${fontClass}`}>
                   "{card.message}"
                </p>
                
                <div className="pt-4 border-t border-current/10 inline-block">
                   <p className={`text-[10px] font-bold uppercase tracking-[0.3em] opacity-40 mb-1 ${theme.text}`}>A wish from</p>
                   <p className={`text-2xl font-bold tracking-tighter ${theme.text}`}>{card.sender}</p>
                </div>
             </footer>
          </div>

          {/* Action Controls dock - No Print */}
          <div data-html2canvas-ignore="true" className="absolute bottom-8 right-8 flex items-center gap-3 no-print">
             <button 
               onClick={handleDownload} 
               title="Download Image"
               className="p-4 bg-white/10 backdrop-blur-xl border border-white/20 rounded-full text-white hover:bg-white/20 transition-all shadow-lg active:scale-95"
             >
                <Download className="w-5 h-5" />
             </button>
             
             <button 
               onClick={handleShare}
               title="Share Card"
               className="p-4 bg-white/10 backdrop-blur-xl border border-white/20 rounded-full text-white hover:bg-white/20 transition-all shadow-lg active:scale-95"
             >
                <Share2 className="w-5 h-5" />
             </button>

             <button 
               onClick={onGenerateVideo} 
               className="px-6 py-4 bg-white text-rose-600 rounded-full text-[10px] font-bold uppercase tracking-widest shadow-xl hover:scale-105 transition-all flex items-center gap-2 border border-rose-100"
             >
                <Sparkles className="w-4 h-4" /> AI Story
             </button>
          </div>
        </div>
      </div>

      {/* Share Modal */}
      {showShareModal && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-6 bg-slate-950/40 backdrop-blur-md no-print animate-in fade-in duration-300">
           <div className="relative w-full max-w-md bg-white rounded-[2.5rem] shadow-2xl p-8 space-y-8 animate-in zoom-in-95 duration-300">
              <button onClick={() => setShowShareModal(false)} className="absolute top-6 right-6 p-2 text-slate-300 hover:text-rose-500 transition-colors">
                <X className="w-6 h-6" />
              </button>

              <div className="text-center space-y-2">
                <div className="w-16 h-16 bg-rose-50 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Share2 className="w-8 h-8 text-rose-500" />
                </div>
                <h3 className="text-2xl font-bold tracking-tight text-slate-900">Share Your Wish.</h3>
                <p className="text-slate-500 text-sm">Send this link to your loved one so they can see your unique Valentine creation.</p>
              </div>

              <div className="space-y-4">
                 <div className="relative">
                    <input 
                      type="text" 
                      readOnly 
                      value={shareUrl} 
                      className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-6 py-4 text-xs font-medium text-slate-400 pr-12"
                    />
                    <div className="absolute right-4 top-1/2 -translate-y-1/2">
                       <Copy className="w-4 h-4 text-slate-300" />
                    </div>
                 </div>

                 <button 
                   onClick={copyToClipboard}
                   className={`w-full py-4 rounded-full font-bold uppercase tracking-widest text-xs transition-all flex items-center justify-center gap-2 ${isCopying ? 'bg-emerald-500 text-white shadow-xl shadow-emerald-100' : 'bg-rose-600 text-white shadow-xl shadow-rose-100 hover:bg-rose-700'}`}
                 >
                    {isCopying ? (
                      <>
                        <Check className="w-4 h-4" /> Copied to Clipboard
                      </>
                    ) : (
                      'Copy Share Link'
                    )}
                 </button>
              </div>
              
              <p className="text-[10px] text-center text-slate-300 font-bold uppercase tracking-widest">
                 Your love, shared instantly.
              </p>
           </div>
        </div>
      )}
    </>
  );
};

export default CardPreview;