
import React, { useState, useEffect, useRef } from 'react';
import { Heart, X, Download, Loader2 } from 'lucide-react';

interface CinematicStoryProps {
  script: string[];
  imageUrl: string | null;
  memoryImages?: string[];
  musicUrl?: string;
  onClose: () => void;
  onComplete?: (videoUrl: string) => void;
}

const DEFAULT_MUSIC = "https://assets.mixkit.co/music/preview/mixkit-romantic-slow-piano-242.mp3";

const CinematicStory: React.FC<CinematicStoryProps> = ({ script, imageUrl, memoryImages = [], musicUrl, onClose, onComplete }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFinished, setIsFinished] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [recordedBlob, setRecordedBlob] = useState<Blob | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const requestRef = useRef<number>(0);
  
  // Combine single image and memory images
  const allImages = imageUrl ? [imageUrl, ...memoryImages] : memoryImages;
  
  const stateRef = useRef({
    startTime: 0,
    zoom: 1,
    opacity: 0,
    text: script[0],
    particles: [] as any[],
    loadedImages: [] as HTMLImageElement[],
  });

  // Preload all images
  useEffect(() => {
    const loaders = allImages.map(src => {
      return new Promise<HTMLImageElement>((resolve) => {
        const img = new Image();
        img.crossOrigin = "anonymous";
        img.onload = () => resolve(img);
        img.onerror = () => resolve(img); // Still resolve to avoid blocking
        img.src = src;
      });
    });

    Promise.all(loaders).then(imgs => {
      stateRef.current.loadedImages = imgs;
    });

    stateRef.current.particles = Array.from({ length: 15 }, () => ({
      x: Math.random() * 100,
      y: Math.random() * 100,
      s: 0.5 + Math.random(),
      v: 0.02 + Math.random() * 0.05
    }));
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const draw = (time: number) => {
      if (!stateRef.current.startTime) stateRef.current.startTime = time;
      const elapsed = time - stateRef.current.startTime;
      
      canvas.width = 1080;
      canvas.height = 1920;
      const w = canvas.width;
      const h = canvas.height;

      ctx.fillStyle = '#000';
      ctx.fillRect(0, 0, w, h);

      // Determine current image and script part
      const partDuration = 5000;
      const index = Math.min(script.length - 1, Math.floor(elapsed / partDuration));
      const partElapsed = elapsed % partDuration;
      
      // Cycle through loaded images if more than one exists
      const imagesCount = stateRef.current.loadedImages.length;
      const imageIdx = imagesCount > 0 ? (index % imagesCount) : -1;
      const currentImg = imageIdx !== -1 ? stateRef.current.loadedImages[imageIdx] : null;

      // Draw Background / Ken Burns
      if (currentImg && currentImg.complete) {
        const scale = 1.1 + (Math.sin(elapsed / 10000) * 0.1);
        const iw = w * scale;
        const ih = h * scale;
        
        // Transition Fade
        let imgAlpha = 0.4;
        if (partElapsed < 1000) imgAlpha = (partElapsed / 1000) * 0.4;
        else if (partElapsed > 4000) imgAlpha = (1 - (partElapsed - 4000) / 1000) * 0.4;
        
        ctx.globalAlpha = imgAlpha;
        ctx.drawImage(currentImg, (w - iw) / 2, (h - ih) / 2, iw, ih);
        ctx.globalAlpha = 1.0;
      } else {
        const grad = ctx.createLinearGradient(0, 0, 0, h);
        grad.addColorStop(0, '#4c0519');
        grad.addColorStop(1, '#000');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, w, h);
      }

      // Watermark
      ctx.globalAlpha = 0.4;
      ctx.font = 'bold 30px "Dancing Script", cursive';
      ctx.fillStyle = '#fff';
      ctx.textAlign = 'right';
      ctx.fillText(" ❤️Cupid's Canvas", w - 40, 60);
      ctx.globalAlpha = 1.0;

      // Particles
      ctx.fillStyle = 'rgba(251, 113, 133, 0.3)';
      stateRef.current.particles.forEach(p => {
        p.y -= p.v;
        if (p.y < -5) p.y = 105;
        ctx.beginPath();
        ctx.arc((p.x * w) / 100, (p.y * h) / 100, 10 * p.s, 0, Math.PI * 2);
        ctx.fill();
      });

      // Text Logic
      let textAlpha = 0;
      if (partElapsed < 1000) textAlpha = partElapsed / 1000;
      else if (partElapsed > 4000) textAlpha = 1 - (partElapsed - 4000) / 1000;
      else textAlpha = 1;

      if (index !== currentIndex) setCurrentIndex(index);
      if (elapsed > script.length * partDuration) {
        setIsFinished(true);
        stopRecording();
        return;
      }

      ctx.font = 'bold 60px "Dancing Script", cursive';
      ctx.fillStyle = `rgba(255, 255, 255, ${textAlpha})`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      
      const wrapText = (context: CanvasRenderingContext2D, text: string, maxWidth: number) => {
        const words = text.split(' ');
        const lines = [];
        let currentLine = words[0];
        for (let n = 1; n < words.length; n++) {
          const width = context.measureText(currentLine + " " + words[n]).width;
          if (width < maxWidth) currentLine += " " + words[n];
          else { lines.push(currentLine); currentLine = words[n]; }
        }
        lines.push(currentLine);
        return lines;
      };

      const lines = wrapText(ctx, script[index], w * 0.8);
      lines.forEach((line, i) => {
        ctx.fillText(line, w / 2, (h / 2) - ((lines.length - 1) * 40) + (i * 80));
      });

      requestRef.current = requestAnimationFrame(draw);
    };

    const startRecording = (audioElement: HTMLAudioElement) => {
      const canvasStream = canvas.captureStream(30);
      const AudioContextClass = (window.AudioContext || (window as any).webkitAudioContext);
      const audioCtx = new AudioContextClass();
      
      try {
        const source = audioCtx.createMediaElementSource(audioElement);
        const destination = audioCtx.createMediaStreamDestination();
        source.connect(audioCtx.destination);
        source.connect(destination);
        
        const combinedStream = new MediaStream([...canvasStream.getVideoTracks(), destination.stream.getAudioTracks()[0]]);
        const recorder = new MediaRecorder(combinedStream, { mimeType: 'video/webm;codecs=vp9' });
        
        recorderRef.current = recorder;
        recorder.ondataavailable = (e) => { if (e.data.size > 0) chunksRef.current.push(e.data); };
        recorder.onstop = () => {
          const blob = new Blob(chunksRef.current, { type: 'video/webm' });
          const url = URL.createObjectURL(blob);
          setVideoUrl(url);
          setIsRecording(false);
          if (onComplete) onComplete(url);
          audioCtx.close();
        };
        recorder.start();
        setIsRecording(true);
      } catch (err) {
        const recorder = new MediaRecorder(canvasStream, { mimeType: 'video/webm;codecs=vp9' });
        recorderRef.current = recorder;
        recorder.ondataavailable = (e) => { if (e.data.size > 0) chunksRef.current.push(e.data); };
        recorder.onstop = () => {
          const blob = new Blob(chunksRef.current, { type: 'video/webm' });
          const url = URL.createObjectURL(blob);
          setVideoUrl(url);
          setIsRecording(false);
          if (onComplete) onComplete(url);
          audioCtx.close();
        };
        recorder.start();
        setIsRecording(true);
      }
    };

    const stopRecording = () => {
      if (recorderRef.current && recorderRef.current.state !== 'inactive') {
        recorderRef.current.stop();
      }
    };

    const audio = new Audio(musicUrl || DEFAULT_MUSIC);
    audio.crossOrigin = "anonymous";
    audio.loop = true;
    audio.volume = 0.5;
    audioRef.current = audio;
    
    const run = async () => {
      try { await audio.play(); } catch (e) {}
      startRecording(audio);
      requestRef.current = requestAnimationFrame(draw);
    };

    run();

    return () => {
      cancelAnimationFrame(requestRef.current);
      audio.pause();
      stopRecording();
    };
  }, [script, musicUrl]);

  return (
    <div className="fixed inset-0 z-[100] bg-black flex flex-col items-center justify-center overflow-hidden">
      <canvas ref={canvasRef} className="h-[80vh] aspect-[9/16] bg-slate-900 shadow-2xl rounded-lg" />
      <div className="absolute top-8 right-8 flex gap-4 z-50">
        <button onClick={onClose} className="text-white/50 hover:text-white transition-colors p-2 hover:bg-white/10 rounded-full">
          <X className="w-8 h-8" />
        </button>
      </div>
      <div className="absolute bottom-12 flex flex-col items-center gap-6 z-50">
        <div className="flex gap-2">
          {script.map((_, i) => (
            <div key={i} className={`h-1.5 rounded-full transition-all duration-500 ${i <= currentIndex ? 'w-8 bg-rose-500' : 'w-2 bg-white/20'}`} />
          ))}
        </div>
        {isFinished && (
          <div className="flex flex-col sm:flex-row gap-4">
            <button onClick={() => videoUrl && window.open(videoUrl)} className="bg-white text-rose-600 px-8 py-3 rounded-full font-bold flex items-center gap-2 hover:scale-105 transition-all">
              <Download className="w-5 h-5" /> Download Video
            </button>
            <button onClick={onClose} className="bg-rose-600 text-white px-8 py-3 rounded-full font-bold flex items-center gap-2 hover:scale-105 transition-all">
              <Heart className="w-5 h-5 fill-current" /> Finish Wish
            </button>
          </div>
        )}
        {isRecording && !isFinished && (
          <div className="flex items-center gap-2 text-rose-400 font-bold text-xs uppercase tracking-widest bg-black/40 px-4 py-2 rounded-full border border-rose-500/30">
            <div className="w-2 h-2 bg-rose-500 rounded-full animate-pulse" />
            AI Rendering {allImages.length > 1 ? `(${allImages.length} Memories)` : ""}
          </div>
        )}
      </div>
      <div className="absolute inset-0 pointer-events-none bg-gradient-to-t from-black via-transparent to-black opacity-60" />
    </div>
  );
};

export default CinematicStory;
