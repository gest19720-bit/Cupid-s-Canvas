
import React from 'react';
import { Heart, Scroll } from 'lucide-react';

const About: React.FC = () => {
  return (
    <div className="max-w-3xl mx-auto py-12 space-y-12 animate-in slide-in-from-bottom duration-700">
      <div className="text-center space-y-4">
        <Scroll className="w-12 h-12 text-rose-500 mx-auto mb-4" />
        <h2 className="text-4xl font-romantic text-rose-600">The Legend of St. Valentine</h2>
        <div className="h-1 w-24 bg-rose-200 mx-auto rounded-full" />
      </div>

      <div className="prose prose-rose max-w-none space-y-6 text-slate-700 text-lg leading-relaxed italic">
        <p>
          The story of Valentine's Day is rooted in a legend of secret devotion and unwavering love. During the 3rd century in Rome, Emperor Claudius II decided that single men made better soldiers than those with wives and families, and thus, he outlawed marriage for young men.
        </p>
        
        <p className="bg-rose-50 p-8 rounded-[2rem] border-l-4 border-rose-500 shadow-sm not-italic font-serif text-slate-800">
          "Valentine, a brave priest of the time, realized the injustice of the decree. In the quiet shadows of the night, he continued to perform marriages for young lovers in secret."
        </p>

        <p>
          When Valentine’s actions were discovered, he was sentenced to death. Legend says that while in prison, he fell in love with the jailer's daughter. Before his execution on February 14th, he allegedly sent her a final letter signed, <span className="text-rose-600 font-bold">"From your Valentine,"</span> an expression that is still used today.
        </p>

        <p>
          Today, we carry on this tradition not just through letters, but through any gesture that says, "I see you, and I care." <strong>Cupid's Canvas</strong> was built to bridge that ancient sentiment with modern technology, allowing everyone to become a digital poet for the ones they love.
        </p>
      </div>

      <div className="flex justify-center pt-8">
        <div className="relative group">
          <Heart className="w-16 h-16 text-rose-500 fill-rose-100 group-hover:scale-110 transition-transform cursor-pointer" />
          <Heart className="w-8 h-8 text-rose-500 fill-rose-500 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
        </div>
      </div>
    </div>
  );
};

export default About;
