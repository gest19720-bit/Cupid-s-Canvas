export interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  links?: { title: string; uri: string }[];
}

export type AiMode = 'fast' | 'thinking' | 'search';

export type CardTheme = 
  | 'classic' 
  | 'midnight' 
  | 'vintage' 
  | 'modern' 
  | 'garden' 
  | 'celestial' 
  | 'minimalist' 
  | 'pastel'
  | 'forest'
  | 'sunset'
  | 'royal'
  | 'ocean'
  | 'noir'
  | 'sakura';

export interface CardState {
  recipient: string;
  sender: string;
  message: string;
  imageUrl: string | null;
  theme: CardTheme;
  fontFamily: string;
  memoryImages?: string[];
}

export interface SavedCard extends CardState {
  id: string;
  createdAt: number;
}

export type AppMode = 'home' | 'editor' | 'preview' | 'about' | 'gallery';