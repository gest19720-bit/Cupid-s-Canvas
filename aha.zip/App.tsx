import React, { useState, useRef, useEffect } from 'react';
import { 
  Heart, 
  Sparkles, 
  ImageIcon, 
  Loader2, 
  ArrowRight,
  Menu,
  X,
  Type as TypeIcon
} from 'lucide-react';
import { editImageWithAI, generateCinematicStory, selectRomanticMusic } from './geminiService';
import { CardState, AppMode, SavedCard, CardTheme } from './types';
import ChatBot from './components/ChatBot';
import CardPreview from './components/CardPreview';
import Home from './components/Home';
import Footer from './components/Footer';
import Gallery from './components/Gallery';
import CinematicStory from './components/CinematicStory';
import VideoMemorySection from './components/VideoMemorySection';
import About from './components/About';

const INITIAL_CARD: CardState = {
  recipient: 'Amara',
  sender: 'Julian',
  message: 'In every version of reality, it has always been you. My heart belongs wherever you are. ❤️',
  imageUrl: null,
  theme: 'classic',
  fontFamily: 'romantic',
  memoryImages: []
};

const THEMES: { id: CardTheme; label: string; color: string }[] = [
  { id: 'minimalist', label: 'Ivory Silk', color: 'bg-white border border-slate-100' },
  { id: 'midnight', label: 'Onyx Star', color: 'bg-slate-950' },
  { id: 'vintage', label: 'Eternity', color: 'bg-[#fdf6e3]' },
  { id: 'classic', label: 'Crimson', color: 'bg-rose-600' },
  { id: 'celestial', label: 'Deep Cosmos', color: 'bg-indigo-950' },
  { id: 'pastel', label: 'Blush', color: 'bg-rose-50' },
  { id: 'forest', label: 'Enchanted', color: 'bg-emerald-900' },
  { id: 'sunset', label: 'Golden Hour', color: 'bg-orange-500' },
  { id: 'royal', label: 'Majesty', color: 'bg-purple-900' },
  { id: 'ocean', label: 'Deep Sea', color: 'bg-cyan-900' },
  { id: 'noir', label: 'Cinema Noir', color: 'bg-black' },
  { id: 'sakura', label: 'Cherry Blossom', color: 'bg-[#fff1f2]' },
];

const FONTS = [
  { id: 'romantic', label: 'Script', class: 'font-romantic' },
  { id: 'elegant', label: 'Display', class: 'font-elegant' },
  { id: 'serif-soft', label: 'Serif', class: 'font-serif-soft' },
  { id: 'inter', label: 'Modern', class: 'font-sans' },
  { id: 'script-alt', label: 'Flamboyant', class: 'font-script-alt' },
];

const App: React.FC = () => {
  const [card, setCard] = useState<CardState>(INITIAL_CARD);
  const [savedCards, setSavedCards] = useState<SavedCard[]>([]);
  const [isEditingImage, setIsEditingImage] = useState(false);
  const [editPrompt, setEditPrompt] = useState('');
  const [mode, setMode] = useState<AppMode>('home');
  const [isAssistantOpen, setIsAssistantOpen] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isStoryLoading, setIsStoryLoading] = useState(false);
  const [storyScript, setStoryScript] = useState<string[] | null>(null);
  const [selectedMusic, setSelectedMusic] = useState<string | null>(null);
  const [showStoryPlayer, setShowStoryPlayer] = useState(false);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const sharedData = params.get('wish');
    if (sharedData) {
      try {
        // Use a robust way to decode base64 that handles Unicode
        const binary = atob(sharedData);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
        const decodedString = new TextDecoder().decode(bytes);
        const decoded = JSON.parse(decodedString);
        
        setCard(prev => ({ ...prev, ...decoded }));
        setMode('preview');
      } catch (e) { 
        console.error("Decoding share link failed:", e); 
      }
    }
    const stored = localStorage.getItem('cupids_canvas_saved');
    if (stored) {
      try { setSavedCards(JSON.parse(stored)); } catch (e) { console.error(e); }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('cupids_canvas_saved', JSON.stringify(savedCards));
  }, [savedCards]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setCard(prev => ({ ...prev, imageUrl: reader.result as string }));
        setVideoUrl(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleEditImage = async () => {
    if (!card.imageUrl || !editPrompt) return;
    setIsEditingImage(true);
    try {
      const result = await editImageWithAI(card.imageUrl, editPrompt);
      if (result) {
        setCard(prev => ({ ...prev, imageUrl: result }));
        setEditPrompt('');
        setVideoUrl(null);
      }
    } catch (err) {
      alert("AI brush snagged. Please try again!");
    } finally {
      setIsEditingImage(false);
    }
  };

  const handleStartCinematicStory = async () => {
    setIsStoryLoading(true);
    try {
      const [script, music] = await Promise.all([
        generateCinematicStory(card.recipient, card.sender, card.message),
        selectRomanticMusic(card.message)
      ]);
      setStoryScript(script);
      setSelectedMusic(music);
      setShowStoryPlayer(true);
    } catch (err) {
      alert("Couldn't generate the story.");
    } finally {
      setIsStoryLoading(false);
    }
  };

  const handleSave = () => {
    const newSaved: SavedCard = { ...card, id: Date.now().toString(), createdAt: Date.now() };
    setSavedCards(prev => [newSaved, ...prev]);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  const renderContent = () => {
    switch (mode) {
      case 'home':
        return <Home onStart={() => setMode('editor')} />;
      case 'gallery':
        return <Gallery cards={savedCards} onView={(c) => { setCard(c); setMode('preview'); }} onDelete={(id) => setSavedCards(prev => prev.filter(c => c.id !== id))} />;
      case 'about':
        return <About />;
      case 'preview':
        return (
          <div className="max-w-5xl mx-auto py-12 space-y-12">
            <div className="flex justify-between items-center no-print">
              <button onClick={() => setMode('editor')} className="text-sm font-bold uppercase tracking-widest text-slate-400 hover:text-rose-500 transition-colors flex items-center gap-2">
                <ArrowRight className="w-4 h-4 rotate-180" /> Back to Studio
              </button>
              <div className="flex gap-4">
                <button onClick={handleSave} className="px-6 py-3 bg-white/40 border border-slate-200/50 backdrop-blur-md rounded-full text-xs font-bold uppercase tracking-widest hover:border-rose-500 transition-all">
                  {saveSuccess ? 'Saved' : 'Save Locally'}
                </button>
                <button onClick={() => setMode('editor')} className="px-6 py-3 bg-rose-600/90 backdrop-blur-md text-white border border-rose-400/30 rounded-full text-xs font-bold uppercase tracking-widest shadow-xl shadow-rose-200 hover:bg-rose-700 transition-all">
                  Edit Card
                </button>
              </div>
            </div>
            <CardPreview card={card} fullSize onGenerateVideo={handleStartCinematicStory} videoUrl={videoUrl} />
            <VideoMemorySection images={card.memoryImages || []} onImagesChange={(imgs) => setCard(p => ({ ...p, memoryImages: imgs }))} onGenerate={() => {}} isLoading={isStoryLoading} />
          </div>
        );
      case 'editor':
        return (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 py-8 items-start">
            <div className="lg:col-span-5 space-y-10">
              <div className="space-y-2">
                <h2 className="text-5xl font-bold tracking-tighter text-slate-900">Studio.</h2>
                <p className="text-slate-500 text-lg">Compose your digital heirloom.</p>
              </div>

              <div className="space-y-8">
                <div className="space-y-6">
                  <label className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-400">Voices of Love</label>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <span className="text-[9px] uppercase font-bold text-slate-300 ml-1">Your Name</span>
                      <input 
                        type="text" 
                        value={card.sender} 
                        onChange={(e) => setCard(p => ({ ...p, sender: e.target.value }))}
                        className="w-full bg-white/50 border border-slate-200/50 rounded-2xl px-6 py-4 text-lg backdrop-blur-sm"
                        placeholder="Julian"
                      />
                    </div>
                    <div className="space-y-1">
                      <span className="text-[9px] uppercase font-bold text-slate-300 ml-1">Their Name</span>
                      <input 
                        type="text" 
                        value={card.recipient} 
                        onChange={(e) => setCard(p => ({ ...p, recipient: e.target.value }))}
                        className="w-full bg-white/50 border border-slate-200/50 rounded-2xl px-6 py-4 text-lg backdrop-blur-sm"
                        placeholder="Amara"
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                       <span className="text-[9px] uppercase font-bold text-slate-300 ml-1">Typography</span>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {FONTS.map(f => (
                        <button 
                          key={f.id}
                          onClick={() => setCard(p => ({ ...p, fontFamily: f.id }))}
                          className={`px-4 py-2 rounded-xl text-[11px] font-bold uppercase tracking-widest transition-all ${card.fontFamily === f.id ? 'bg-slate-900 text-white shadow-lg' : 'bg-white border border-slate-100 text-slate-400 hover:border-rose-200'}`}
                        >
                          {f.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-1">
                    <span className="text-[9px] uppercase font-bold text-slate-300 ml-1">The Message</span>
                    <textarea 
                      value={card.message} 
                      onChange={(e) => setCard(p => ({ ...p, message: e.target.value }))}
                      className={`w-full bg-white/50 border border-slate-200/50 rounded-2xl px-6 py-4 text-lg h-32 resize-none backdrop-blur-sm ${FONTS.find(f => f.id === card.fontFamily)?.class}`}
                      placeholder="Your heartfelt message..."
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <label className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-400">Atmosphere</label>
                  <div className="grid grid-cols-6 gap-3">
                    {THEMES.map(t => (
                      <button 
                        key={t.id} 
                        onClick={() => setCard(p => ({ ...p, theme: t.id }))}
                        className={`w-10 h-10 rounded-full ring-offset-2 transition-all ${t.color} ${card.theme === t.id ? 'ring-2 ring-rose-500 scale-110 shadow-lg' : 'hover:scale-105'}`}
                        title={t.label}
                      />
                    ))}
                  </div>
                </div>

                <div className="space-y-4">
                  <label className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-400">Media</label>
                  <div className="relative group cursor-pointer aspect-video bg-white/50 border-2 border-dashed border-slate-200/50 rounded-3xl overflow-hidden flex flex-col items-center justify-center gap-2 hover:border-rose-300 transition-all backdrop-blur-sm" onClick={() => fileInputRef.current?.click()}>
                    {card.imageUrl ? (
                      <img src={card.imageUrl} className="absolute inset-0 w-full h-full object-cover" alt="Preview" />
                    ) : (
                      <>
                        <ImageIcon className="w-8 h-8 text-slate-300" />
                        <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Main Portrait</span>
                      </>
                    )}
                    <input type="file" ref={fileInputRef} onChange={handleImageUpload} className="hidden" accept="image/*" />
                  </div>
                  
                  <div className="relative">
                    <input 
                      type="text" 
                      value={editPrompt}
                      onChange={(e) => setEditPrompt(e.target.value)}
                      placeholder="Ask AI to transform this photo..."
                      className="w-full bg-slate-100/50 border border-slate-200/30 rounded-2xl pl-6 pr-12 py-4 text-sm font-medium backdrop-blur-sm"
                    />
                    <button 
                      onClick={handleEditImage}
                      disabled={!card.imageUrl || isEditingImage}
                      className="absolute right-3 top-2 p-2 bg-rose-600/90 text-white border border-rose-400/30 rounded-xl disabled:bg-slate-300 backdrop-blur-sm"
                    >
                      {isEditingImage ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button 
                  onClick={() => setMode('preview')}
                  className="w-full py-5 bg-slate-900/90 backdrop-blur-md text-white border border-slate-700/50 rounded-full font-bold uppercase tracking-widest text-xs hover:bg-slate-800 transition-all shadow-2xl shadow-slate-200"
                >
                  Finalize Card
                </button>
              </div>
            </div>

            <div className="lg:col-span-7 sticky top-32 hidden lg:block">
              <div className="flex flex-col items-center">
                 <label className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-400 mb-8">Live Preview</label>
                 <CardPreview card={card} />
              </div>
            </div>
          </div>
        );
    }
  };

  const navLinks = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About' },
    { id: 'gallery', label: 'Gallery' },
    { id: 'editor', label: 'Create Card' }
  ];

  return (
    <div className="min-h-screen flex flex-col selection:bg-rose-100 selection:text-rose-900">
      <nav className="sticky top-0 z-[100] h-24 no-print flex items-center">
        <div className="max-w-7xl mx-auto w-full px-8 flex items-center justify-between">
          
          {/* Logo Container Pod */}
          <div 
            onClick={() => setMode('home')} 
            className="flex items-center gap-3 cursor-pointer group px-5 py-2.5 rounded-2xl bg-white/40 border border-white/50 backdrop-blur-xl shadow-lg shadow-rose-500/5 transition-all hover:bg-white/60"
          >
            <div className="bg-rose-600 p-2 rounded-xl group-hover:rotate-6 transition-transform">
              <Heart className="w-5 h-5 text-white fill-white" />
            </div>
            <h1 className="text-xl font-bold tracking-tighter text-slate-900">Cupid's Canvas<span className="text-rose-600 italic">.</span></h1>
          </div>

          {/* Navigation Links Pod - Reordered: Home, About, Gallery, Create Card */}
          <div className="hidden md:flex items-center gap-1 p-1.5 bg-white/40 border border-white/50 rounded-full backdrop-blur-xl shadow-lg shadow-slate-500/5">
            {navLinks.map((m) => (
              <button 
                key={m.id} 
                onClick={() => setMode(m.id as AppMode)}
                className={`px-5 py-2 rounded-full text-[10px] font-bold uppercase tracking-[0.2em] transition-all ${mode === m.id ? 'bg-rose-500 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50/50 hover:text-rose-600'}`}
              >
                {m.label}
              </button>
            ))}
          </div>

          {/* Action Buttons Pod */}
          <div className="flex items-center gap-3 px-3 py-1.5 bg-white/40 border border-white/50 rounded-2xl backdrop-blur-xl shadow-lg shadow-slate-500/5">
            <button 
              onClick={() => setIsAssistantOpen(true)}
              className="p-3 bg-rose-50/50 text-rose-600 rounded-xl hover:bg-rose-100 transition-all border border-rose-100/30 backdrop-blur-sm"
            >
              <Sparkles className="w-5 h-5" />
            </button>
            <button 
              onClick={() => setMode('editor')}
              className="px-6 py-2.5 bg-slate-900/90 text-white border border-slate-700/50 rounded-xl text-[10px] font-bold uppercase tracking-widest hover:bg-slate-800 transition-all hidden sm:block backdrop-blur-sm shadow-md"
            >
              Create
            </button>
            <button className="md:hidden p-2 text-slate-500" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
              {isMobileMenuOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Nav */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-[110] bg-white flex flex-col p-8 space-y-8 no-print">
          <div className="flex justify-between items-center">
             <h1 className="text-2xl font-bold tracking-tighter">Menu<span className="text-rose-600">.</span></h1>
             <X onClick={() => setIsMobileMenuOpen(false)} />
          </div>
          {navLinks.map(m => (
            <button key={m.id} onClick={() => { setMode(m.id as AppMode); setIsMobileMenuOpen(false); }} className="text-4xl font-bold tracking-tighter text-left capitalize">
              {m.label}
            </button>
          ))}
        </div>
      )}

      <main className="flex-1 max-w-7xl mx-auto w-full px-8 mt-4">
        {renderContent()}
      </main>

      <Footer />

      {/* AI Assistant Modal */}
      {isAssistantOpen && (
        <div className="fixed inset-0 z-[150] flex items-center justify-center p-6 bg-slate-950/20 backdrop-blur-sm no-print">
          <div className="relative w-full max-w-lg h-[600px] bg-white rounded-[2.5rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300">
            <ChatBot onClose={() => setIsAssistantOpen(false)} />
          </div>
        </div>
      )}

      {/* Story Reveal */}
      {showStoryPlayer && storyScript && (
        <CinematicStory 
          script={storyScript} 
          imageUrl={card.imageUrl} 
          memoryImages={card.memoryImages}
          musicUrl={selectedMusic || undefined}
          onClose={() => setShowStoryPlayer(false)}
        />
      )}

      {/* Luxury Loader */}
      {isStoryLoading && (
        <div className="fixed inset-0 z-[200] bg-white/90 backdrop-blur-xl flex flex-col items-center justify-center text-center">
          <div className="relative mb-8">
             <div className="w-16 h-16 border border-slate-200 border-t-rose-600 rounded-full animate-spin" />
             <Heart className="w-6 h-6 text-rose-600 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 animate-pulse fill-current" />
          </div>
          <p className="text-[10px] font-bold uppercase tracking-[0.4em] text-slate-400 animate-pulse">Designing the Moment</p>
        </div>
      )}
    </div>
  );
};

export default App;