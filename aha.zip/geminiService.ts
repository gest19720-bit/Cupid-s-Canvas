import { GoogleGenAI, GenerateContentResponse, Chat, Type, GenerateContentParameters } from "@google/genai";
import { AiMode } from "./types";

/**
 * Utility to get the AI client instance.
 * Guidelines require instance creation right before making an API call 
 * to ensure it uses the most up-to-date API key from the selection dialog.
 */
const getAIClient = () => {
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

/**
 * Robust retry logic with exponential backoff to handle transient 500/Rpc errors.
 */
async function withRetry<T>(fn: () => Promise<T>, retries = 3, delay = 1000): Promise<T> {
  try {
    return await fn();
  } catch (error: any) {
    const isRetryable = error?.code === 500 || error?.status === "UNKNOWN" || error?.message?.includes("Rpc failed");
    if (retries > 0 && isRetryable) {
      console.warn(`AI call failed, retrying in ${delay}ms... (${retries} retries left)`, error);
      await new Promise(resolve => setTimeout(resolve, delay));
      return withRetry(fn, retries - 1, delay * 2);
    }
    throw error;
  }
}

export const editImageWithAI = async (
  base64Image: string,
  prompt: string
): Promise<string | null> => {
  return withRetry(async () => {
    const ai = getAIClient();
    // Ensure we strip the data URL prefix if present
    const imageData = base64Image.includes(',') ? base64Image.split(',')[1] : base64Image;
    const mimeType = base64Image.includes(';') ? base64Image.split(';')[0].split(':')[1] : 'image/png';

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          {
            inlineData: {
              data: imageData,
              mimeType: mimeType,
            },
          },
          {
            text: `Edit this image based on the following instruction for a Valentine's card: ${prompt}. Ensure the result is high quality and romantic.`,
          },
        ],
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return null;
  });
};

export const suggestRomanticImages = async (recipient: string, message: string): Promise<string[]> => {
  return withRetry(async () => {
    const ai = getAIClient();
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Suggest 3 specific, highly romantic visual concepts for a Valentine's card for ${recipient}. The message is: "${message}". Format as a simple list of 3 descriptive prompts. Plain text only.`,
    });
    return response.text?.split('\n').filter(line => line.trim().length > 0).slice(0, 3) || [];
  });
};

export const selectRomanticMusic = async (message: string): Promise<string> => {
  return withRetry(async () => {
    const ai = getAIClient();
    const tracks = {
      "piano": "https://assets.mixkit.co/music/preview/mixkit-romantic-slow-piano-242.mp3",
      "tender": "https://assets.mixkit.co/music/preview/mixkit-tender-love-153.mp3",
      "dreamy": "https://assets.mixkit.co/music/preview/mixkit-beautiful-dream-493.mp3",
      "emotional": "https://assets.mixkit.co/music/preview/mixkit-slow-emotional-strings-track-2182.mp3"
    };

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Based on this Valentine message: "${message}", which musical mood fits best?
      Choose exactly one key from this list: "piano", "tender", "dreamy", "emotional".
      Respond with ONLY the key name.`,
    });
    const key = response.text?.trim().toLowerCase() as keyof typeof tracks;
    return tracks[key] || tracks.piano;
  });
};

export const generateCinematicStory = async (recipient: string, sender: string, userMessage: string): Promise<string[]> => {
  return withRetry(async () => {
    const ai = getAIClient();
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Write a cinematic 5-part romantic story reveal for ${recipient} from ${sender}. 
      The core message is: "${userMessage}". 
      Each part should be a short, poetic sentence (max 12 words). 
      Format as a JSON array of strings. 
      Example: ["Once in a lifetime, a soul finds its twin.", "In the quiet moments, I see your smile.", ...]`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: { type: Type.STRING }
        }
      }
    });
    
    const text = response.text || "[]";
    return JSON.parse(text);
  });
};

export const generateMemoryNarrative = async (images: string[], recipient: string, sender: string): Promise<string[]> => {
  return withRetry(async () => {
    const ai = getAIClient();
    
    const imageParts = images.slice(0, 5).map(img => {
      const imageData = img.includes(',') ? img.split(',')[1] : img;
      const mimeType = img.includes(';') ? img.split(';')[0].split(':')[1] : 'image/png';
      return {
        inlineData: {
          data: imageData,
          mimeType: mimeType
        }
      };
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: {
        parts: [
          ...imageParts,
          { text: `Analyze these ${images.length} photos and write a beautiful, cohesive romantic narrative of ${sender} and ${recipient}'s time together. Create exactly ${Math.max(5, Math.min(images.length, 10))} poetic sentences. Return as a JSON array of strings. Plain, elegant language only.` }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: { type: Type.STRING }
        }
      }
    });

    return JSON.parse(response.text || "[]");
  });
};

export const createChat = (systemInstruction: string, mode: AiMode = 'fast'): Chat => {
  const ai = getAIClient();
  let modelName = 'gemini-3-flash-preview';
  let config: any = { systemInstruction };

  if (mode === 'thinking') {
    modelName = 'gemini-3-pro-preview';
    config.thinkingConfig = { thinkingBudget: 32768 };
  } else if (mode === 'search') {
    modelName = 'gemini-3-flash-preview';
    config.tools = [{ googleSearch: {} }];
  } else if (mode === 'fast') {
    modelName = 'gemini-flash-lite-latest';
  }

  return ai.chats.create({
    model: modelName,
    config,
  });
};